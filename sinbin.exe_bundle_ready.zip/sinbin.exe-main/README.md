# COLOR AS THEORY › TEXT

> _“Theory speaks through sequence.  
> Color speaks through sensation.”_

---

### ● RED  
**Will. Force. Instinct.**

### ● ORANGE  
**Vital Energy. Awakening. Pulse.**

### ● YELLOW  
**Clarity. Power. Structure.**

### ● GREEN  
**Growth. Adaptation. Balance.**

### ● CYAN  
**Thought. Reflection. Flow.**

### ● INDIGO  
**Sight. Depth. Vision.**

### ● VIOLET  
**Spirit. Transcendence. Memory.**

---

> These are not decorations.  
> They are **encoded resonance** — shortcuts to understanding, to feeling, to structure itself.  
>  
> **In the Scroll, color is not a finish. It is a foundation.**

---

[**▶ Launch sinbin.exe →**](sinbin.html)
